<?php
namespace App\Http\Controllers;
use App\Services\Business\AdminBusinessDataService;
use Illuminate\Http\Request;

class AdminManagementController extends Controller
{
   
    public function readAllUsers(){
        
        $adminManagement = new AdminBusinessDataService();
        $data = $adminManagement->read();
        $users = Array();
        while ($row = mysqli_fetch_assoc($data)) {
           array_push($users, $row);
        }
        return view('internals/admin')->with('users',$users);
    }
    
    public function ChangeUserStatus(Request $request){
        $userId = $request->input('userId');
        $adminManagement = new AdminBusinessDataService();
        $adminManagement->ChangeStatus($userId);
        
        $adminManagement = new AdminBusinessDataService();
        $data = $adminManagement->read();
        $users = Array();
        while ($row = mysqli_fetch_assoc($data)) {
            array_push($users, $row);
        }
        return view('internals/admin')->with('users',$users);
    }
    
    public function DeleteUser(Request $request){
        
        $userId = $request->input('userId');
        $adminManagement = new AdminBusinessDataService();
        $adminManagement->delete($userId);
        
        $adminManagement = new AdminBusinessDataService();
        $data = $adminManagement->read();
        $users = Array();
        while ($row = mysqli_fetch_assoc($data)) {
            array_push($users, $row);
        }
        return view('internals/admin')->with('users',$users);
    }
    
    public function adminViewGroups(){
        $adminManagement = new AdminBusinessDataService();
        $data = $adminManagement->getAllGroup();
        $groups = Array();
        while ($row = mysqli_fetch_assoc($data)) {
            array_push($groups, $row);
        }
        return view('group/adminViewGroup')->with('groups',$groups);
    }
    public function deactivaGroup(Request $request){
        $groupId = $request->input('groupID');
        $adminManagement = new AdminBusinessDataService();
        $adminManagement->deactiveGroup($groupId);
        $data = $adminManagement->getAllGroup();
        $groups = Array();
        while ($row = mysqli_fetch_assoc($data)) {
            array_push($groups, $row);
        }
        return redirect('adminViewGroup');
    }
}
