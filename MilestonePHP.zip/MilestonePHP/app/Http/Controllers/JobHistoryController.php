<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\Business\JobHistoryBusinessDataSerivce;

class JobHistoryController extends Controller
{
        public function readAllJobHistory(){
        
        $jobHistoryDataSerivce = new JobHistoryBusinessDataSerivce();
        $data = $jobHistoryDataSerivce->read();
        
        $JobHistoryModels = Array();
        while ($row = mysqli_fetch_assoc($data)) {
            array_push($JobHistoryModels, $row);
        }
        return view('jobHistory')->with('JobHistoryModels',$JobHistoryModels);
    }
}
